
public class WhipCream  extends coffeeMaker {
       public WhipCream(coffee coffeemaker) {
      super(coffeemaker);		
   }

   @Override
   public void make() {
      coffeemaker.make();	       
      settopping1(coffeemaker);
   }

   private void settopping1(coffee coffeemaker ){
      System.out.println("Topping added: Whip Cream");
   }

    
}
