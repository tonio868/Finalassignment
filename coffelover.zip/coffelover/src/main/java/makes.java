
import java.text.DecimalFormat;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ANTONIO
 */
public class makes {
    public class Worker implements componet {
    
    private String name;
    private String type;
    
    
public Worker(String name, String type){
    
    this.name = name;
    this.type = type;
    
    
}// end of initialisation 


    @Override
    public String name() {
        return name;
    }

    @Override
    public String type() {
        return type;
    }

    

    @Override
    public void display() {
        DecimalFormat df = new DecimalFormat("$.00");
            
            System.out.print(name()+ "\n");	
            System.out.println(type());
             
    }

    @Override
    public void add(componet coffee) {
        
    }
}

}