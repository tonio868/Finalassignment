
public abstract class coffeeMaker implements coffee{
    protected coffee coffeemaker;

   public coffeeMaker(coffee coffeemaker){
      this.coffeemaker = coffeemaker;
   }

   public void draw(){
      coffeemaker.make();
   }	
    
}
