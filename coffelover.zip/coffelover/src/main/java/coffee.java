
public interface coffee {
    void make();

   
    
    
}

