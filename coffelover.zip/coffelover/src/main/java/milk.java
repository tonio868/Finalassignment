public class milk  extends coffeeMaker {
       public milk(coffee coffeemaker) {
      super(coffeemaker);		
   }

   @Override
   public void make() {
      coffeemaker.make();	       
      settopping2(coffeemaker);
   }

   private void settopping2(coffee coffeemaker ){
      System.out.println("Topping added: milk");
   }

    
}
