
import java.util.Scanner;
import java.util.*;

public class DecoratorPatternDemo {
   public static void main(String[] args) {
        /*Coffee type*/
      coffee decaf = new Decaf();
      coffee house = new HouseBlend();
      coffee espress = new Espresso();
      coffee Dark = new DarkRoast();
      
        /*milk coffee*/
      coffee milkcaf = new milk(new Decaf());
      coffee milkhouse = new milk(new HouseBlend());
      coffee milkespress = new milk(new Espresso());
      coffee milkDark = new milk(new DarkRoast());
     
      
      /*WhipCream*/
      coffee creamcaf = new WhipCream(new Decaf());
      coffee creamhouse = new WhipCream(new HouseBlend());
      coffee creamespress = new WhipCream(new Espresso());
      coffee creamDark = new WhipCream(new DarkRoast());
      
      /*Mocha*/
      coffee mochacaf = new Mocha(new Decaf());
      coffee mochahouse = new Mocha(new HouseBlend());
      coffee mochaespress = new Mocha(new Espresso());
      coffee mochaDark = new Mocha(new DarkRoast());
      
      /*Chocolate Syrup*/
      coffee chococaf = new ChocolateSyrup(new Decaf());
      coffee chocohouse = new ChocolateSyrup(new HouseBlend());
      coffee chocoespress = new ChocolateSyrup(new Espresso());
      coffee chocoDark = new ChocolateSyrup(new DarkRoast());
     
      /*Caramel Syrup*/
      coffee carmelcaf = new CaramelSyrup(new Decaf());
      coffee carmelhouse = new CaramelSyrup(new HouseBlend());
      coffee carmelespress = new CaramelSyrup(new Espresso());
      coffee carmelDark = new CaramelSyrup(new DarkRoast());
      
      componet Cdecafs = new Maker ("Decaf, cream");
      componet Chouse = new Maker ("House Blend, cream");
      componet Cespress = new Maker ("Espresso, cream");
      componet Cdark = new Maker ("Dark Roast, cream");
       
   
      
       
      componet Mdecafs = new Maker ("Decaf, milk");
      componet Mhouse = new Maker ("House Blend, milk");
      componet Mespress = new Maker ("Espresso, milk");
      componet Mdark = new Maker ("Dark Roast, milk");
      
       componet MHdecafs = new Maker ("Decaf, Mocha");
      componet MHhouse = new Maker ("House Blend, Mocha");
      componet MHespress = new Maker ("Espresso, Mocha");
      componet MHdark = new Maker ("Dark Roast, Mocha");
      
      componet ChSdecafs = new Maker ("Decaf, Chocolate Syrup");
      componet ChSMhouse = new Maker ("House Blend, Chocolate Syrup");
      componet ChSMespress = new Maker ("Espresso, Chocolate Syrup");
      componet ChSMdark = new Maker ("Dark Roast, Chocolate Syrup");
      
      componet Cardecafs = new Maker ("Decaf, Caramel Syrup");
      componet CarMhouse = new Maker ("House Blend, Caramel Syrup");
      componet CarMespress = new Maker ("Espresso, Caramel Syrup");
      componet CarMdark = new Maker ("Dark Roast, Caramel Syrup");
       
       
         
      
      Scanner input = new Scanner(System.in);
      int x;
      int z;
           
      System.out.println("Welcome to the Coffee maker!");
       System.out.println("Please Enjoy your stay!");
        System.out.println("What would your order be?");
        System.out.println("1.Decaf");
        System.out.println("2.HouseBlend");
        System.out.println("3.Espresso");
        System.out.println("4.DarkRoast");
        int n = input.nextInt();
        
        switch(n){
            case 1: 
                System.out.println("\n would you like a topping or not?");
                System.out.println("\n 1.Yes?");
                System.out.println("\n 1.No?");
                   x = input.nextInt();
               
                switch(x){
            case 1: System.out.println("1.Milk");
                    System.out.println("2.WhipCream");
                    System.out.println("3.Mocha");
                    System.out.println("4.Chocolate Syrup");
                    System.out.println("5.Caramel Syrup");
                          z = input.nextInt();
                             switch(z){
                                 case 1: milkcaf.make();
                                    System.out.println("\n Thank your for purchasing from Coffer Maker");
                                    System.out.println("\n Enjoy your Day!");
                                        break;
                                  case 2: creamcaf.make();
                                    System.out.println("\n Thank your for purchasing from Coffer Maker");
                                    System.out.println("\n Enjoy your Day!");
                                         break;
                                         case 3: mochacaf.make();
                                    System.out.println("\n Thank your for purchasing from Coffer Maker");
                                    System.out.println("\n Enjoy your Day!");
                                         break;
                                         case 4: chococaf.make();
                                    System.out.println("\n Thank your for purchasing from Coffer Maker");
                                    System.out.println("\n Enjoy your Day!");
                                         break;
                                         case 5: carmelcaf.make();
                                    System.out.println("\n Thank your for purchasing from Coffer Maker");
                                    System.out.println("\n Enjoy your Day!");
                                         break;
                                        
                             }
                
            case 2:
                decaf.make();
                 System.out.println("\n Here  your Coffee!");
                 System.out.println("\n Thank your for purchasing from Coffer Maker");
                 System.out.println("\n Enjoy your Day!");
                break;
                
                }
                
                case 2: 
                System.out.println("\n would you like a topping or not?");
                System.out.println("\n 1.Yes?");
                System.out.println("\n 1.No?");
                   x = input.nextInt();
               
                switch(x){
            case 1: System.out.println("1.Milk");
                    System.out.println("2.WhipCream");
                    System.out.println("3.Mocha");
                    System.out.println("4.Chocolate Syrup");
                    System.out.println("5.Caramel Syrup");
                          z = input.nextInt();
                             switch(z){
                                 case 1: milkhouse.make();
                                    System.out.println("\n Thank your for purchasing from Coffer Maker");
                                    System.out.println("\n Enjoy your Day!");
                                        break;
                                  case 2: creamhouse.make();
                                    System.out.println("\n Thank your for purchasing from Coffer Maker");
                                    System.out.println("\n Enjoy your Day!");
                                         break;
                                         case 3: mochahouse.make();
                                    System.out.println("\n Thank your for purchasing from Coffer Maker");
                                    System.out.println("\n Enjoy your Day!");
                                         break;
                                         case 4: chocohouse.make();
                                    System.out.println("\n Thank your for purchasing from Coffer Maker");
                                    System.out.println("\n Enjoy your Day!");
                                         break;
                                         case 5: carmelhouse.make();
                                    System.out.println("\n Thank your for purchasing from Coffer Maker");
                                    System.out.println("\n Enjoy your Day!");
                                         break;
                                        
                             }
                
            case 2:
                house.make();
                 System.out.println("\n Here  your Coffee!");
                 System.out.println("\n Thank your for purchasing from Coffer Maker");
                  System.out.println("\n Enjoy your Day!");
                break;
                
                }
                   
                case 3: 
                System.out.println("\n would you like a topping or not?");
                System.out.println("\n 1.Yes?");
                System.out.println("\n 1.No?");
                   x = input.nextInt();
               
                switch(x){
            case 1: System.out.println("1.Milk");
                    System.out.println("2.WhipCream");
                    System.out.println("3.Mocha");
                    System.out.println("4.Chocolate Syrup");
                    System.out.println("5.Caramel Syrup");
                          z = input.nextInt();
                             switch(z){
                                 case 1: milkespress.make();
                                    System.out.println("\n Thank your for purchasing from Coffer Maker");
                                    System.out.println("\n Enjoy your Day!");
                                        break;
                                  case 2: creamespress.make();
                                    System.out.println("\n Thank your for purchasing from Coffer Maker");
                                    System.out.println("\n Enjoy your Day!");
                                         break;
                                         case 3: mochaespress.make();
                                    System.out.println("\n Thank your for purchasing from Coffer Maker");
                                    System.out.println("\n Enjoy your Day!");
                                         break;
                                         case 4: chocoespress.make();
                                    System.out.println("\n Thank your for purchasing from Coffer Maker");
                                    System.out.println("\n Enjoy your Day!");
                                         break;
                                         case 5: carmelespress.make();
                                    System.out.println("\n Thank your for purchasing from Coffer Maker");
                                    System.out.println("\n Enjoy your Day!");
                                         break;
                                        
                             }
                
            case 2:
                espress.make();
                 System.out.println("\n Here  your Coffee!");
                 System.out.println("\n Thank your for purchasing from Coffer Maker");
                  System.out.println("\n Enjoy your Day!");
                break;
                }
                 
                case 4: 
                System.out.println("\n would you like a topping or not?");
                System.out.println("\n 1.Yes?");
                System.out.println("\n 1.No?");
                   x = input.nextInt();
               
                switch(x){
            case 1: System.out.println("1.Milk");
                    System.out.println("2.WhipCream");
                    System.out.println("3.Mocha");
                    System.out.println("4.Chocolate Syrup");
                    System.out.println("5.Caramel Syrup");
                          z = input.nextInt();
                             switch(z){
                                 case 1: milkDark.make();
                                    System.out.println("\n Thank your for purchasing from Coffer Maker");
                                    System.out.println("\n Enjoy your Day!");
                                        break;
                                  case 2: creamDark.make();
                                    System.out.println("\n Thank your for purchasing from Coffer Maker");
                                    System.out.println("\n Enjoy your Day!");
                                         break;
                                         case 3: mochaDark.make();
                                    System.out.println("\n Thank your for purchasing from Coffer Maker");
                                    System.out.println("\n Enjoy your Day!");
                                         break;
                                         case 4: chocoDark.make();
                                                 
                                    System.out.println("\n Thank your for purchasing from Coffer Maker");
                                    System.out.println("\n Enjoy your Day!");
                                         break;
                                         case 5: carmelDark.make();
                                    System.out.println("\n Thank your for purchasing from Coffer Maker");
                                    System.out.println("\n Enjoy your Day!");
                                         break;
                                        
                             }
                
            case 2:
                Dark.make();
                 System.out.println("\n Here  your Coffee!");
                 System.out.println("\n Thank your for purchasing from Coffer Maker");
                  System.out.println("\n Enjoy your Day!");
                break;
                }
                
            default:
                
                break;
                
                
        
        }
      
      

      
   }
}