
public class Espresso implements coffee{
     @Override
   public void make() {
      System.out.println("You order a Espresso");
   }
    
}
