  import java.util .ArrayList;
import java.util.Iterator;
import java.util.List;
  
public class Maker implements componet{
  
    ArrayList<componet> coffees = new ArrayList<componet>();
    private String coffee;
   private String type;
   
   private List<Maker> order;

   // constructor
   public Maker(String coffee,String type) {
      this.coffee = coffee;
      this.type = type;
      
      
   }

    Maker(String decaf_cream) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void add(componet coffee_drinks) {
        coffee_drinks.add(coffee_drinks);
    }

    @Override
    public String name() {
        return coffee;
        
    }

    @Override
    public String type() {
        return type;
    }

   
    @Override
    public void display() {
        System.out.print("\n"+ name() + "\n" + type() + "\n");
        System.out.println("---------------------");
        
        
            Iterator<componet> iterator = coffees.iterator();
            while (iterator.hasNext()) {
                    componet coffee_drinks = (componet)iterator.next();
                    coffee_drinks.display();
                                       }
                           }
}

