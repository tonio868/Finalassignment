public class CaramelSyrup extends coffeeMaker {
       public CaramelSyrup(coffee coffeemaker) {
      super(coffeemaker);		
   }

   @Override
   public void make() {
      coffeemaker.make();	       
      settopping4(coffeemaker);
   }

   private void settopping4(coffee coffeemaker ){
      System.out.println("Topping added: Caramel Syrup");
   }

    
}
