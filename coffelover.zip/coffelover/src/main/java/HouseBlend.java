
public class HouseBlend implements coffee{
    @Override
   public void make() {
      System.out.println("You order a House Blend");
   }
    
}
