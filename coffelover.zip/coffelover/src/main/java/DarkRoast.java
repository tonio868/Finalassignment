
public class DarkRoast implements coffee {
     @Override
   public void make() {
      System.out.println("You order a Dark Roast");
   }
    
}
