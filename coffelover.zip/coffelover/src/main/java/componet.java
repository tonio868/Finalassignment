/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ANTONIO
 */
public interface componet {
    public void add(componet coffee_drinks );

    public String name();

    public String type ();
    
    public void display();
}
