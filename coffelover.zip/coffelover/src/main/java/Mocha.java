public class Mocha extends coffeeMaker {
       public Mocha(coffee coffeemaker) {
      super(coffeemaker);		
   }

   @Override
   public void make() {
      coffeemaker.make();	       
      settopping3(coffeemaker);
   }

   private void settopping3(coffee coffeemaker ){
      System.out.println("Topping added: Mocha");
   }

    
}
